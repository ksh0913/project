package com.mysite.bookkkeureom.feed.DTO;

public class PostCommentDTO {
    private int commentId;
    private int postId;
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
    
}
