package com.mysite.bookkkeureom.feed.DAO;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.apache.ibatis.session.SqlSession;
import com.mysite.bookkkeureom.feed.DTO.CommentDTO;
import java.util.List;

@Repository
public class CommentDAOImpl implements CommentDAO {

    private final SqlSession sqlSession;

    @Autowired
    public CommentDAOImpl(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }

    @Override
    public void createComment(CommentDTO comment) throws Exception {
        sqlSession.insert("CommentMapper.createComment", comment);
    }

    @Override
    public CommentDTO readComment(int commentId) throws Exception {
        return sqlSession.selectOne("CommentMapper.getCommentById", commentId);
    }

    @Override
    public void updateComment(CommentDTO comment) throws Exception {
        sqlSession.update("CommentMapper.updateComment", comment);
    }

    @Override
    public void deleteComment(int commentId) throws Exception {
        sqlSession.delete("CommentMapper.deleteComment", commentId);
    }

    @Override
    public List<CommentDTO> commentListAll() throws Exception {
        return sqlSession.selectList("CommentMapper.getAllComments");
    }

    @Override
    public List<CommentDTO> getCommentsByPostId(int postId) throws Exception {
        return sqlSession.selectList("CommentMapper.getCommentsByPostId", postId);
    }
}
