function logout() {
    Kakao.Auth.logout()
        .then(function (response) {
            console.log(Kakao.Auth.getAccessToken());
        })
        .catch(function (error) {
            console.log('Not logged in.');
        });
}  