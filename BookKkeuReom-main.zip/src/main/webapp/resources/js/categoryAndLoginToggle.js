$(document).ready(function () {
    $(".btn-primary").click(function () {
        $(".modal").modal("hide");
        $(".navbar-toggler-icon").removeClass("active")
    })
})