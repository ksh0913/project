package com.mysite.bookkkeureom.feed.DAO;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.mysite.bookkkeureom.feed.DTO.CommentDTO;

public interface CommentDAO {

    // 새로운 댓글 추가
    void createComment(CommentDTO comment) throws Exception;

    // 댓글 조회
    CommentDTO readComment(int commentId) throws Exception;

    // 댓글 정보 업데이트
    void updateComment(CommentDTO comment) throws Exception;

    // 댓글 삭제
    void deleteComment(int commentId) throws Exception;

    // 모든 댓글 리스트 조회
    List<CommentDTO> commentListAll() throws Exception;

    // 특정 게시물의 댓글 조회
    List<CommentDTO> getCommentsByPostId(@Param("postId") int postId) throws Exception;
}
