package com.mysite.bookkkeureom.feed.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mysite.bookkkeureom.feed.DAO.CommentDAO;
import com.mysite.bookkkeureom.feed.DTO.CommentDTO;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    private final CommentDAO commentDAO;

    @Autowired
    public CommentServiceImpl(CommentDAO commentDAO) {
        this.commentDAO = commentDAO;
    }

    @Override
    public void addComment(CommentDTO comment) throws Exception {
        commentDAO.createComment(comment);
    }

    @Override
    public CommentDTO getCommentById(int commentId) throws Exception {
        return commentDAO.readComment(commentId);
    }

    @Override
    public void updateComment(CommentDTO comment) throws Exception {
        commentDAO.updateComment(comment);
    }

    @Override
    public void deleteComment(int commentId) throws Exception {
        commentDAO.deleteComment(commentId);
    }

    @Override
    public List<CommentDTO> getAllComments() throws Exception {
        return commentDAO.commentListAll();
    }

    @Override
    public List<CommentDTO> getCommentsByPostId(int postId) throws Exception {
        return commentDAO.getCommentsByPostId(postId);
    }
}
