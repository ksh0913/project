package com.mysite.bookkkeureom.feed.service;

import com.mysite.bookkkeureom.feed.DTO.CommentDTO;
import java.util.List;

public interface CommentService {
    void addComment(CommentDTO comment) throws Exception;
    
    CommentDTO getCommentById(int commentId) throws Exception;
    
    void updateComment(CommentDTO comment) throws Exception;
    
    void deleteComment(int commentId) throws Exception;
    
    List<CommentDTO> getAllComments() throws Exception;
    
    List<CommentDTO> getCommentsByPostId(int postId) throws Exception;
}
