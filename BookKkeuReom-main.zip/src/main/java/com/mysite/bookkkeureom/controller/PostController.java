package com.mysite.bookkkeureom.controller;

import com.mysite.bookkkeureom.feed.DTO.PostDTO;
import com.mysite.bookkkeureom.feed.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpSession;

import java.util.List;

@Controller
public class PostController {
    private static final Logger logger = LoggerFactory.getLogger(PostController.class);

    @Autowired
    private PostService postService;

    @GetMapping("/posts")
    public String showPostList(Model model) {
        try {
            List<PostDTO> posts = postService.getAllPosts();
            model.addAttribute("posts", posts);
        } catch (Exception e) {
            logger.error("포스트 목록을 불러오는 중 오류 발생", e);
            model.addAttribute("error", "포스트 목록을 불러오는 중 오류가 발생하였습니다.");
        }
        
        return "postList";
    }

    @GetMapping("/create")
    public String showPostForm() {
        return "postForm";
    }

    @PostMapping("/postCreate")
    public String createPost(PostDTO post, Model model, HttpSession session) {
        try {
            postService.createPost(post);
            return "redirect:/posts";
        } catch (Exception e) {
            logger.error("포스트 생성 중 오류 발생", e);
            model.addAttribute("error", "포스트를 생성하는 중 오류가 발생했습니다.");
            return "redirect:/create";
        }
    }

    @GetMapping("/{postId}")
    public String getPostDetails(@PathVariable int postId, Model model) {
        try {
            PostDTO post = postService.getPostById(postId);
            model.addAttribute("post", post);
            return "postDetails";
        } catch (Exception e) {
            logger.error("포스트 상세 조회 중 오류 발생", e);
            model.addAttribute("errorMessage", "포스트를 조회하는 중 오류가 발생했습니다.");
            return "postForm";
        }
    }

    @PostMapping("/posts/update/{postId}")
    public String updatePost(@PathVariable int postId, PostDTO updatedPost, HttpSession session, Model model) {
        try {
            updatedPost.setPostId(postId);
            postService.updatePost(updatedPost);
            return "redirect:/" + postId;
        } catch (Exception e) {
            logger.error("포스트 업데이트 중 오류 발생", e);
            model.addAttribute("error", "포스트를 업데이트하는 중 오류가 발생했습니다.");
            return "redirect:/posts/edit/" + postId;
        }
    }

    @GetMapping("/posts/delete/{postId}")
    public String deletePost(@PathVariable int postId, HttpSession session, Model model) {
        try {
            postService.deletePost(postId);
            return "redirect:/posts";
        } catch (Exception e) {
            logger.error("포스트 삭제 중 오류 발생", e);
            model.addAttribute("error", "포스트를 삭제하는 중 오류가 발생했습니다.");
            return "redirect:/" + postId;
        }
    }
}
