$(".progress-bar").animate(
  {
    width: "100%",
  },
  14000
);
